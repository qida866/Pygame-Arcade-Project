# 【入口文件】主循环，负责把所有东西组装起来
# 运行这个文件来启动游戏。它负责加载资源、处理逻辑和显示界面


import pygame
import random
import os
import sys

# 导入配置和各个模块
from settings import *
from sprites import Cart, Fruit, Bomb, PowerUp, Particle
from utils import load_high_score, save_high_score
from renderer import GameRenderer  # 导入负责画画的渲染器【修改】

class Game:
    def __init__(self):
        # 1. 初始化 Pygame 和 窗口
        pygame.init()
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption(GAME_TITLE)
        self.clock = pygame.time.Clock()

        # 2. 初始化渲染器 (把屏幕交给它)
        self.renderer = GameRenderer(self.screen)

        # 3. 加载资源 (图片和分数)
        self.fruit_images = {}
        self.load_fruit_images()
        self.high_score = load_high_score()

        # 4. 初始化游戏状态
        self.state = "menu"  # 状态: menu, playing, game_over
        self.reset_game()
        # 【11.29新增】初始化帧计数器，用于控制动画和粒子
        self.frame_count = 0 
        self.reset_game()

    def load_fruit_images(self):
        """加载所有水果图片到内存中"""
        print(f"Loading images from: {FRUIT_IMAGES_PATH}")
        
        # 检查文件夹是否存在
        if not os.path.exists(FRUIT_IMAGES_PATH):
            print(f"Warning: Directory not found at {FRUIT_IMAGES_PATH}. Creating it...")
            try:
                os.makedirs(FRUIT_IMAGES_PATH, exist_ok=True)
            except Exception as e:
                print(f"Could not create directory: {e}")

        for name, _, filename in FRUITS_DATA:
            filepath = os.path.join(FRUIT_IMAGES_PATH, filename)
            try:
                # 加载并转换图片格式
                image = pygame.image.load(filepath).convert_alpha()
                
                # 根据不同水果调整大小
                if name == "Banana":
                    image = pygame.transform.scale(image, (65, 65))
                else:
                    image = pygame.transform.scale(image, (50, 50))
                
                self.fruit_images[name] = image
                print(f"Loaded: {name}")
            except Exception as e:
                # 如果加载失败（比如图片不存在），这就设为 None，Sprite类会自动画圆圈代替
                print(f"Failed to load {name} ({filename}): {e}")
                self.fruit_images[name] = None

    def reset_game(self):
        """重置所有游戏数据，准备新的一局"""
        self.cart = Cart()
        self.fruits = []
        self.bombs = []
        self.powerups = []
        self.particles = []

        self.score = 0
        self.time_left = GAME_TIME
        self.bombs_caught = 0
        self.wrong_caught = 0
        self.combo = 0
        self.max_combo = 0
        
        # 计时器归零
        self.frame_count = 0
        self.fruit_timer = 0
        self.bomb_timer = 0
        self.powerup_timer = 0
        
        # 道具状态
        self.double_points_active = False
        self.double_points_frames = 0

        # 随机选择一个新的目标水果
        index = random.randint(0, len(FRUITS_DATA) - 1)
        self.target_name, self.target_color, _ = FRUITS_DATA[index]

    def spawn_fruit(self):
        """生成一个水果（有概率是目标水果，也有概率是干扰水果）"""
        roll = random.random()
        # 65% 概率生成目标水果
        if roll < 0.65:
            name = self.target_name
            color = self.target_color
            is_target = True
        else:
            # 从非目标水果中随机选一个
            others = [f for f in FRUITS_DATA if f[0] != self.target_name]
            name, color, _ = random.choice(others)
            is_target = False

        image = self.fruit_images.get(name)
        # 创建水果对象并加入列表
        self.fruits.append(Fruit(name, color, image, is_target))

    def handle_events(self):
        """处理键盘和鼠标输入"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            # 菜单界面的输入
            if self.state == "menu":
                if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                    self.reset_game()
                    self.state = "playing"

            # 游戏结束界面的输入
            elif self.state == "game_over":
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        self.reset_game()
                        self.state = "playing"
                    elif event.key == pygame.K_ESCAPE:
                        self.state = "menu"

        # 游戏进行时的持续按键检测（移动车子）
        if self.state == "playing":
            keys = pygame.key.get_pressed()
            direction = 0
            if keys[pygame.K_LEFT] or keys[pygame.K_a]:
                direction = -1
            elif keys[pygame.K_RIGHT] or keys[pygame.K_d]:
                direction = 1
            
            self.cart.move(direction)

    def update_playing(self):
        """游戏进行时的逻辑更新（每帧运行）"""
        self.frame_count += 1
        
        # 1. 处理倒计时
        if self.frame_count % FPS == 0:
            self.time_left -= 1
            if self.time_left <= 0:
                self.end_game()

        # 2. 生成物体 (根据计时器)
        self.fruit_timer += 1
        if self.fruit_timer >= FRUIT_SPAWN_FRAMES:
            self.spawn_fruit()
            self.fruit_timer = 0
        
        self.bomb_timer += 1
        if self.bomb_timer >= BOMB_SPAWN_FRAMES:
            self.bombs.append(Bomb())
            self.bomb_timer = 0

        self.powerup_timer += 1
        if self.powerup_timer >= POWERUP_SPAWN_FRAMES:
            self.powerups.append(PowerUp())
            self.powerup_timer = 0

        # 3. 更新双倍积分道具时间
        if self.double_points_active:
            self.double_points_frames -= 1
            if self.double_points_frames <= 0:
                self.double_points_active = False

        # 4. 碰撞检测与物体移除
        self.check_collisions()
        
        # 5. 更新粒子特效 (只保留还没消失的粒子)
        self.particles = [p for p in self.particles if p.life > 0]
        for p in self.particles:
            p.update()

    def check_collisions(self):
        """核心逻辑：检测车子有没有接到东西"""
        cart_rect = self.cart.get_rect()

        # --- 检查水果 ---
        # 使用切片 [:] 复制列表进行遍历，因为我们可能会在遍历时删除元素
        for fruit in self.fruits[:]:
            fruit.update()
            
            # 掉出屏幕移除
            if fruit.is_off_screen():
                self.fruits.remove(fruit)
                continue
            
            # 碰撞检测
            if fruit.get_rect().colliderect(cart_rect):
                self.fruits.remove(fruit)
                # 生成粒子特效
                for _ in range(10):
                    self.particles.append(Particle(fruit.x, fruit.y, fruit.color))
                
                # 计分逻辑
                if fruit.is_target:
                    base_points = 10
                    if self.double_points_active:
                        base_points *= 2
                    self.score += base_points
                    self.combo += 1
                    self.max_combo = max(self.combo, self.max_combo)
                else:
                    self.wrong_caught += 1
                    self.combo = 0
                    if self.wrong_caught >= MAX_WRONG:
                        self.end_game()

        # --- 检查炸弹 ---
        for bomb in self.bombs[:]:
            bomb.update()
            if bomb.is_off_screen():
                self.bombs.remove(bomb)
                continue
            if bomb.get_rect().colliderect(cart_rect):
                self.bombs.remove(bomb)
                self.bombs_caught += 1
                self.combo = 0
                
                # 炸弹特效
                for _ in range(20):
                    self.particles.append(Particle(bomb.x, bomb.y, RED))
                
                if self.bombs_caught >= MAX_BOMBS:
                    self.end_game()

        # --- 检查道具 ---
        for pu in self.powerups[:]:
            pu.update()
            if pu.is_off_screen():
                self.powerups.remove(pu)
                continue
            if pu.get_rect().colliderect(cart_rect):
                self.powerups.remove(pu)
                self.double_points_active = True
                self.double_points_frames = 7 * FPS # 持续 7 秒
                # 道具特效
                for _ in range(15):
                    self.particles.append(Particle(pu.x, pu.y, GOLD))

    def end_game(self):
        """结束游戏并保存分数"""
        # 防止重复触发
        if self.state == "game_over":
            return
            
        self.state = "game_over"
        if self.score > self.high_score:
            self.high_score = self.score
            save_high_score(self.high_score)

    def run(self):
        """主游戏循环"""
        while True:
            # 【11.29新增】每帧递增计数器
            self.frame_count += 1
            
            # 1. 处理输入
            self.handle_events()
            
            # 2. 更新逻辑 (仅在游戏中)
            if self.state == "playing":
                self.update_playing()
            
            # 3. 渲染画面 (核心：把自己传给渲染器，让它去画)
            # 这里的 self 包含了 game.score, game.cart 等所有数据
            self.renderer.draw(self)
            
            # 4. 锁定帧率
            self.clock.tick(FPS)

if __name__ == "__main__":
    game = Game()
    game.run()
