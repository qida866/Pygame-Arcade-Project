# 定义所有的游戏对象：车子、水果、炸弹、道具、粒子。

import pygame
import random
import math
from settings import *

class Cart:
    def __init__(self):
        self.width = 120
        self.height = 26
        self.x = WINDOW_WIDTH // 2 - self.width // 2
        self.y = WINDOW_HEIGHT - 90
        self.speed = CART_SPEED

    def move(self, direction):
        self.x += direction * self.speed
        # 边界检查
        if self.x < 0:
            self.x = 0
        if self.x + self.width > WINDOW_WIDTH:
            self.x = WINDOW_WIDTH - self.width

    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.width, self.height)

    def draw(self, screen):
        # 这里保留原来的绘制代码
        body_rect = self.get_rect()
        # 阴影
        shadow_rect = pygame.Rect(self.x + 3, self.y + 3, self.width, self.height)
        pygame.draw.rect(screen, (100, 100, 100), shadow_rect, border_radius=6)
        # 车身
        pygame.draw.rect(screen, BLUE, body_rect, border_radius=6)
        # 高光
        highlight_rect = pygame.Rect(self.x + 10, self.y + 3, self.width - 20, 8)
        pygame.draw.rect(screen, LIGHT_BLUE, highlight_rect, border_radius=3)
        # 车沿
        lip_rect = pygame.Rect(self.x + 10, self.y - 8, self.width - 20, 10)
        pygame.draw.rect(screen, DARK_GRAY, lip_rect, border_radius=4)
        # 轮子
        wheel_r = 10
        left_wheel_center = (self.x + 18, self.y + self.height + wheel_r - 2)
        right_wheel_center = (self.x + self.width - 18, self.y + self.height + wheel_r - 2)
        pygame.draw.circle(screen, BLACK, left_wheel_center, wheel_r)
        pygame.draw.circle(screen, BLACK, right_wheel_center, wheel_r)
        pygame.draw.circle(screen, GRAY, left_wheel_center, 4)
        pygame.draw.circle(screen, GRAY, right_wheel_center, 4)

class Fruit:
    def __init__(self, name, color, image, is_target):
        self.name = name
        self.color = color
        self.image = image
        self.is_target = is_target
        self.radius = 25
        self.x = random.randint(self.radius, WINDOW_WIDTH - self.radius)
        self.y = -self.radius
        self.speed = FRUIT_SPEED
        self.rotation = 0
        self.scale = 1.0
        self.scale_direction = 0.005

    def update(self):
        self.y += self.speed
        self.rotation += 2
        # 呼吸效果
        self.scale += self.scale_direction
        if self.scale >= 1.05 or self.scale <= 0.95:
            self.scale_direction *= -1

    def is_off_screen(self):
        return self.y - self.radius > WINDOW_HEIGHT

    def get_rect(self):
        return pygame.Rect(self.x - self.radius, self.y - self.radius, self.radius * 2, self.radius * 2)

    def draw(self, screen):
        if self.image:
            img_width = int(self.radius * 2 * self.scale)
            img_height = int(self.radius * 2 * self.scale)
            scaled_image = pygame.transform.scale(self.image, (img_width, img_height))
            rotated_image = pygame.transform.rotate(scaled_image, self.rotation)
            img_rect = rotated_image.get_rect(center=(self.x, self.y))
            screen.blit(rotated_image, img_rect)
        else:
            # 备用绘制：画圆
            pygame.draw.circle(screen, self.color, (self.x, self.y), self.radius)
            pygame.draw.circle(screen, WHITE, (self.x - 6, self.y - 6), 6)

class Bomb:
    def __init__(self):
        self.radius = BOMB_RADIUS
        self.x = random.randint(self.radius, WINDOW_WIDTH - self.radius)
        self.y = -self.radius
        self.speed = BOMB_SPEED
        # 定时器，用于计时和火焰闪烁
        self.fuse_timer = BOMB_FUSE_FRAMES 

    def update(self):
        self.y += self.speed
        self.fuse_timer -= 1
        # 如果计时器归零，可以考虑让炸弹立刻爆炸或加速坠落
        if self.fuse_timer < 0:
            self.fuse_timer = 0 # 保持计时器不为负

    def is_off_screen(self):
        return self.y > WINDOW_HEIGHT

    def get_rect(self):
        # 碰撞检测使用一个矩形，略小于圆形
        return pygame.Rect(self.x - self.radius + 5, self.y - self.radius + 5, 
                           self.radius * 2 - 10, self.radius * 2 - 10)

    def draw(self, screen):
        # 1. 炸弹本体 (黑色圆球)
        pygame.draw.circle(screen, BLACK, (self.x, self.y), self.radius)
        # 2. 灰色描边
        pygame.draw.circle(screen, DARK_GRAY, (self.x, self.y), self.radius, 2)
        
        # 3. 绘制引线
        fuse_start = (self.x, self.y - self.radius)
        fuse_end = (self.x, self.y - self.radius - 10) # 导线伸出10像素
        pygame.draw.line(screen, BLACK, fuse_start, fuse_end, 2)
        
        # 4. 绘制火焰/闪烁效果 (利用 fuse_timer 创建闪烁动画)
        if self.fuse_timer % 20 < 10:
            pygame.draw.circle(screen, RED, fuse_end, 3)

class PowerUp:
    def __init__(self):
        self.width = 26
        self.height = 26
        self.x = random.randint(0, WINDOW_WIDTH - self.width)
        self.y = -self.height
        self.speed = POWERUP_SPEED
        self.rotation = 0

    def update(self):
        self.y += self.speed
        self.rotation += 3

    def is_off_screen(self):
        return self.y > WINDOW_HEIGHT

    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.width, self.height)

    def draw(self, screen, font):
        rect = self.get_rect()
        pygame.draw.rect(screen, PURPLE, rect, border_radius=4)
        pygame.draw.rect(screen, GOLD, rect, 2, border_radius=4)
        text = font.render("2x", True, WHITE)
        screen.blit(text, (self.x + 2, self.y + 4))

class Particle:
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.vx = random.uniform(-3, 3)
        self.vy = random.uniform(-5, -2)
        self.color = color
        self.life = 30
        self.size = random.randint(3, 6)

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.vy += 0.2
        self.life -= 1
        self.size = max(1, self.size - 0.1)

    def draw(self, screen):
        if self.life > 0:
            pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), int(self.size))
