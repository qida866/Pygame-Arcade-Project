# renderer.py 最终修正版 (包含所有美化和粒子逻辑)

import pygame
import random
from settings import * # 确保所有颜色和常量都已导入

class GameRenderer:
    def __init__(self, screen):
        self.screen = screen
        # 字体初始化
        self.font = pygame.font.Font(None, 32)
        self.small_font = pygame.font.Font(None, 24)
        # 标题字体大小修正为 80，更贴合图片视觉效果
        self.big_font = pygame.font.Font(None, 80) 
        
        # 用于菜单标题的闪烁粒子列表
        self.menu_particles = [] 

    def draw(self, game):
        """主绘制函数"""
        # 1. 绘制背景（渐变天色 + 云朵 + 太阳）- 这是画在最底层的第一步
        self.draw_background()

        # 2. 根据状态分发绘制任务
        if game.state == "menu":
            self.draw_menu(game) 
        elif game.state == "playing":
            self.draw_playing(game)
        elif game.state == "game_over":
            self.draw_game_over(game)

        # 3. 提交显示
        pygame.display.flip()

    def draw_background(self):
        """绘制蓝天白云渐变背景 + 太阳和云朵"""
        # 绘制渐变蓝天 (从 SKY_BLUE 渐变到靠近底部时的 WHITE)
        for y in range(WINDOW_HEIGHT):
            ratio = y / WINDOW_HEIGHT
            # 计算 RGB 值，使得颜色从上到下逐渐变浅（接近白色）
            r = int(SKY_BLUE[0] + (WHITE[0] - SKY_BLUE[0]) * ratio * 0.5) # 调整 ratio 乘数，让底部不要完全变成白色
            g = int(SKY_BLUE[1] + (WHITE[1] - SKY_BLUE[1]) * ratio * 0.5)
            b = int(SKY_BLUE[2] + (WHITE[2] - SKY_BLUE[2]) * ratio * 0.5)
            # 确保颜色值在 0-255 范围内
            r = min(255, max(0, r))
            g = min(255, max(0, g))
            b = min(255, max(0, b))
            pygame.draw.line(self.screen, (r, g, b), (0, y), (WINDOW_WIDTH, y))

        # 绘制太阳 (使用 SUN_COLOR)
        sun_pos = (WINDOW_WIDTH - 80, 80)
        # 绘制光芒/描边效果
        pygame.draw.circle(self.screen, GOLD, sun_pos, 42, 0) # 外层金色光芒
        pygame.draw.circle(self.screen, SUN_COLOR, sun_pos, 35) # 主体颜色
        
        # 绘制云朵 (简化版椭圆组合)
        # 为了更接近图片中的轻薄效果，稍微调整了云朵的位置和形状
        cloud_positions = [
            (100, 100, 50, 30), # 左上角第一朵
            (600, 150, 70, 40), # 右侧
            (350, 60, 60, 35),  # 顶部中间
            (180, 500, 80, 45), # 左下角
            (WINDOW_WIDTH - 120, 500, 50, 30), # 右下角
        ]
        
        for cx, cy, w, h in cloud_positions:
            s = pygame.Surface((w, h), pygame.SRCALPHA)
            s.set_alpha(180) # 设置半透明
            
            # 使用多个圆形/椭圆组合形成一朵云
            pygame.draw.ellipse(s, WHITE, (0, h * 0.2, w * 0.6, h * 0.8))
            pygame.draw.ellipse(s, WHITE, (w * 0.3, 0, w * 0.7, h * 0.7))
            
            self.screen.blit(s, (cx, cy))


    def draw_menu(self, game):
        """
        美化后的菜单界面 (包含标题光晕和三层标题)
        """
        center_x = WINDOW_WIDTH // 2
        
        # 1. 最高分显示 (半透明背景 + 圆角描边)
        hs_bg_width = 200
        hs_bg = pygame.Rect(10, 10, hs_bg_width, 45) 
        
        # 绘制圆角背景
        pygame.draw.rect(self.screen, WHITE, hs_bg, border_radius=20) 
        # 绘制金色描边
        pygame.draw.rect(self.screen, GOLD, hs_bg, 3, border_radius=20) 
        
        # 假设 high_score 存在于 game 对象中
        hs_text = self.font.render(f"BEST SCORE: {game.high_score}", True, BLACK) 
        # 将文本定位在背景框内
        self.screen.blit(hs_text, (20, 18))


        # 2. 标题 "Fruit Catcher" (三层叠加，更立体)
        title_text_1 = "Fruit"
        title_text_2 = "Catcher"
        title_y_1 = 180 # 第一行 Y 坐标
        title_y_2 = 270 # 第二行 Y 坐标
        
        # --- 标题光晕粒子效果 (使用 frame_count) ---
        if hasattr(game, 'frame_count') and game.frame_count % 3 == 0: 
            for _ in range(3):
                # 粒子在两行标题周围生成
                py_base = random.choice([title_y_1, title_y_2])
                px = center_x + random.randint(-180, 180)
                py = py_base + random.randint(-30, 30)
                # [x, y, radius, life]
                self.menu_particles.append([px, py, random.randint(1, 3), 15]) 
        
        # 绘制并更新粒子 (使用 TITLE_SPARKLE_COLOR - 白色)
        self.menu_particles = [p for p in self.menu_particles if p[3] > 0]
        for p in self.menu_particles:
            p[0] += random.uniform(-0.8, 0.8) # 左右轻微漂移
            p[3] -= 1 # 生命周期递减
            # 根据生命值计算透明度（模拟光晕渐隐）
            alpha = int(255 * (p[3] / 15))
            color_with_alpha = TITLE_SPARKLE_COLOR + (alpha,)
            
            s = pygame.Surface((p[2] * 2, p[2] * 2), pygame.SRCALPHA)
            pygame.draw.circle(s, color_with_alpha, (p[2], p[2]), p[2])
            self.screen.blit(s, (int(p[0] - p[2]), int(p[1] - p[2])))


        # --- 绘制标题本体 (三层叠加) ---
        
        def draw_title_line(text, y, offset_x=0, offset_y=0):
            # 层次一：最底层阴影 (使用 TITLE_SHADOW_COLOR)
            title_shadow1 = self.big_font.render(text, True, TITLE_SHADOW_COLOR) 
            self.screen.blit(title_shadow1, title_shadow1.get_rect(center=(center_x + 4 + offset_x, y + 4 + offset_y)))
            
            # 层次二：中层轮廓 (描边效果) 
            title_shadow2 = self.big_font.render(text, True, WHITE)
            self.screen.blit(title_shadow2, title_shadow2.get_rect(center=(center_x + 2 + offset_x, y + 2 + offset_y)))
            
            # 层次三：主体颜色
            title = self.big_font.render(text, True, ORANGE)
            self.screen.blit(title, title.get_rect(center=(center_x + offset_x, y + offset_y)))

        # 绘制两行标题
        draw_title_line(title_text_1, title_y_1)
        draw_title_line(title_text_2, title_y_2)


        # 3. 开始提示 "Press SPACE to start" (调整为图片中的颜色)
        start_msg = self.font.render("Press SPACE to start", True, DARK_GREEN)
        self.screen.blit(start_msg, start_msg.get_rect(center=(center_x, 430))) # Y 坐标下移

        # 4. 操作提示 "Move cart with LEFT/RIGHT" (调整为图片中的颜色)
        help_msg = self.font.render("Move cart with LEFT/RIGHT keys", True, DARK_GREEN)
        self.screen.blit(help_msg, help_msg.get_rect(center=(center_x, 470))) # Y 坐标下移


    # 以下 draw_playing, draw_hud, draw_game_over 保持不变 (根据你的项目结构)

    def draw_playing(self, game):
        # 1. 画游戏物体
        if hasattr(game, 'particles'): 
            for p in game.particles: p.draw(self.screen)
        if hasattr(game, 'fruits'):
            for f in game.fruits: f.draw(self.screen)
        if hasattr(game, 'bombs'):
            for b in game.bombs: b.draw(self.screen)
        if hasattr(game, 'powerups'):
            for p in game.powerups: p.draw(self.screen, self.small_font)
        if hasattr(game, 'cart'):
            game.cart.draw(self.screen)
        
        # 2. 画 UI 面板
        self.draw_hud(game)

    def draw_hud(self, game):
        # 检查必要的属性是否存在，防止运行时错误
        if not all(hasattr(game, attr) for attr in ['score', 'high_score', 'time_left', 'bombs_caught', 'wrong_caught', 'target_color', 'target_name', 'fruit_images', 'combo', 'double_points_active', 'double_points_frames']):
            return # 如果属性不全，跳过 HUD 绘制

        # 左上角：数据面板
        panel_bg = pygame.Rect(5, 5, 200, 140)
        s = pygame.Surface((panel_bg.width, panel_bg.height))
        s.set_alpha(200)
        s.fill(WHITE)
        self.screen.blit(s, (panel_bg.x, panel_bg.y))
        pygame.draw.rect(self.screen, BLUE, panel_bg, 2, border_radius=8)

        score_text = self.small_font.render(f"Score: {game.score}", True, BLACK)
        best_text = self.small_font.render(f"Best: {game.high_score}", True, GOLD)
        time_color = RED if game.time_left <= 10 else BLACK
        time_text = self.small_font.render(f"Time: {game.time_left}", True, time_color)
        bomb_text = self.small_font.render(f"Bombs: {game.bombs_caught}/{MAX_BOMBS}", True, RED)
        wrong_text = self.small_font.render(f"Wrong: {game.wrong_caught}/{MAX_WRONG}", True, ORANGE)

        self.screen.blit(score_text, (15, 15))
        self.screen.blit(best_text, (15, 40))
        self.screen.blit(time_text, (15, 65))
        self.screen.blit(bomb_text, (15, 90))
        self.screen.blit(wrong_text, (15, 115))

        # 右上角：目标水果提示
        target_bg = pygame.Rect(WINDOW_WIDTH - 265, 5, 260, 85)
        s_target = pygame.Surface((target_bg.width, target_bg.height))
        s_target.set_alpha(200)
        s_target.fill(WHITE)
        self.screen.blit(s_target, (target_bg.x, target_bg.y))
        pygame.draw.rect(self.screen, game.target_color, target_bg, 3, border_radius=8)

        label = self.small_font.render("TARGET FRUIT:", True, BLACK)
        self.screen.blit(label, (WINDOW_WIDTH - 255, 15))

        target_image = game.fruit_images.get(game.target_name)
        if target_image:
            preview_image = pygame.transform.scale(target_image, (40, 40))
            self.screen.blit(preview_image, (WINDOW_WIDTH - 235, 35))
        else:
            pygame.draw.circle(self.screen, game.target_color, (WINDOW_WIDTH - 215, 55), 20)

        name_text = self.font.render(game.target_name, True, BLACK)
        self.screen.blit(name_text, (WINDOW_WIDTH - 175, 43))

        # 连击显示
        if game.combo > 1:
            combo_text = self.font.render(f"Combo x{game.combo}!", True, GREEN)
            combo_shadow = self.font.render(f"Combo x{game.combo}!", True, BLACK)
            self.screen.blit(combo_shadow, (WINDOW_WIDTH // 2 - combo_shadow.get_width() // 2 + 2, 12))
            self.screen.blit(combo_text, (WINDOW_WIDTH // 2 - combo_text.get_width() // 2, 10))

        # 双倍积分提示 (瞬时闪烁)
        DOUBLE_POINT_SHOW_FRAMES = 60
        if game.double_points_active and game.double_points_frames > (7 * FPS) - DOUBLE_POINT_SHOW_FRAMES:
            if (game.frame_count // 5) % 2 == 0:
                dp_bg_width = 200
                dp_bg = pygame.Rect(WINDOW_WIDTH // 2 - dp_bg_width // 2, 45, dp_bg_width, 35)
                pygame.draw.rect(self.screen, PURPLE, dp_bg, border_radius=6)
                pygame.draw.rect(self.screen, GOLD, dp_bg, 2, border_radius=6)

                dp_text = self.font.render("DOUBLE POINTS!", True, GOLD)
                dp_rect = dp_text.get_rect(center=dp_bg.center)
                self.screen.blit(dp_text, dp_rect)

    def draw_game_over(self, game):
        overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
        overlay.set_alpha(150)
        overlay.fill(BLACK) 
        self.screen.blit(overlay, (0, 0))

        panel_width = 500
        panel_height = 350
        panel_x = WINDOW_WIDTH // 2 - panel_width // 2
        panel_y = WINDOW_HEIGHT // 2 - panel_height // 2
        panel_rect = pygame.Rect(panel_x, panel_y, panel_width, panel_height)
        
        border_color = GOLD if game.score == game.high_score and game.score > 0 else BLUE
        
        pygame.draw.rect(self.screen, WHITE, panel_rect, border_radius=15)
        pygame.draw.rect(self.screen, border_color, panel_rect, 5, border_radius=15)

        if game.score == game.high_score and game.score > 0:
            title = self.big_font.render("NEW RECORD!", True, GOLD)
        else:
            title = self.big_font.render("Game Over", True, RED)
        title_rect = title.get_rect(center=(WINDOW_WIDTH // 2, panel_y + 50))
        self.screen.blit(title, title_rect)

        y_offset = panel_y + 120
        score_text = self.font.render(f"Your score: {game.score}", True, BLACK)
        best_text = self.font.render(f"Best score: {game.high_score}", True, GOLD)
        
        self.screen.blit(score_text, score_text.get_rect(center=(WINDOW_WIDTH // 2, y_offset)))
        self.screen.blit(best_text, best_text.get_rect(center=(WINDOW_WIDTH // 2, y_offset + 40)))

        reason_text = self.small_font.render(
            f"Bombs: {game.bombs_caught}/{MAX_BOMBS}    Wrong fruits: {game.wrong_caught}/{MAX_WRONG}",
            True, DARK_GRAY
        )
        self.screen.blit(reason_text, reason_text.get_rect(center=(WINDOW_WIDTH // 2, y_offset + 100)))

        info_text = self.small_font.render("SPACE: play again    ESC: menu", True, BLACK)
        self.screen.blit(info_text, info_text.get_rect(center=(WINDOW_WIDTH // 2, y_offset + 160)))
