import json
from settings import HIGH_SCORE_FILE

def load_high_score():
    """从文件加载最高分"""
    try:
        with open(HIGH_SCORE_FILE, "r") as f:
            data = json.load(f)
            return int(data.get("high_score", 0))
    except (FileNotFoundError, json.JSONDecodeError, ValueError):
        return 0

def save_high_score(score):
    """保存最高分到文件"""
    data = {"high_score": int(score)}
    try:
        with open(HIGH_SCORE_FILE, "w") as f:
            json.dump(data, f)
    except Exception as e:
        print(f"Error saving score: {e}")
