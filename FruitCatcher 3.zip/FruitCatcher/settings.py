# 存放所有的常量、颜色和配置。以后如果想改车子速度、窗口大小，只改这里就行

import os

# =========================
# 屏幕与基础设置
# =========================
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
FPS = 60
GAME_TITLE = "Fruit Catcher Factory - Team Project"

# =========================
# 颜色定义 (R, G, B)
# =========================
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (210, 210, 210)
RED = (220, 70, 70)
GREEN = (80, 200, 120)
BLUE = (80, 130, 220)
YELLOW = (245, 230, 100)
PURPLE = (190, 120, 230)
ORANGE = (250, 160, 80)
DARK_GRAY = (60, 60, 60)

# 美化颜色
LIGHT_BLUE = (173, 216, 230)
SKY_BLUE = (135, 206, 250)
GOLD = (255, 215, 0)
DARK_GREEN = (0, 100, 0)
# 菜单美化专用颜色
TITLE_SHADOW_COLOR = (100, 30, 0)
SUN_COLOR = (255, 255, 100)
TITLE_SPARKLE_COLOR = (255, 255, 255) # 粒子闪烁颜色 (也可以直接用 WHITE)

# =========================
# 游戏数值平衡
# =========================
GAME_TIME = 60
MAX_BOMBS = 5
MAX_WRONG = 10

# 生成频率 (帧数)
FRUIT_SPAWN_FRAMES = 35
BOMB_SPAWN_FRAMES = 90
POWERUP_SPAWN_FRAMES = 600

# 移动速度
CART_SPEED = 8
FRUIT_SPEED = 4
BOMB_SPEED = 5
POWERUP_SPEED = 4

# --- 🎯 修复: 炸弹配置 (新增) ---
BOMB_RADIUS = 15
BOMB_FUSE_FRAMES = 120 # 炸弹引线闪烁周期（2秒，120帧）
# ---------------------------------

# =========================
# 路径与资源配置
# =========================
# 获取当前文件所在的目录
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# 假设图片放在 assets/fruits 目录下
FRUIT_IMAGES_PATH = os.path.join(BASE_DIR, "assets", "fruits")
HIGH_SCORE_FILE = os.path.join(BASE_DIR, "high_score.json")

# 水果列表：名字 + 颜色 + 图片文件名
FRUITS_DATA = [
    ("Apple", RED, "apple.png"),
    ("Banana", YELLOW, "banana.png"),
    ("Grape", PURPLE, "grape.png"),
    ("Orange", ORANGE, "orange.png"),
    ("Melon", GREEN, "watermelon.png"),
]
